<template>
    <section class="vh-lg-100 mt-5 mt-lg-0 bg-soft d-flex align-items-center">
        <div class="container">
            <div class="row justify-content-center form-bg-image" style="background: url('/assets/images/signin.svg');">
                <div class="col-12 d-flex align-items-center justify-content-center">

                    <slot />

    

                </div>
            </div>
        </div>
    </section>
    <div class="text-center">
       <span>Created by: Sabar Ngoding</span>
    </div>
</template>


<script>
    export default {

    }
</script>